# ansible

Provisioning that runs **locally on each Pi**, started by `bootstrap.sh`:

```
ansible-playbook -i localhost, -c local site.yml -e manifest_path=/opt/inventory/infra/<version>/manifest.json
```

The release manifest is the single source for what gets installed (image digests, versions). Only `ansible.builtin` modules are used, so the `ansible-core` from Debian's apt is enough (2.14 on Bookworm).

| Role | Does |
|---|---|
| `hardware` | Detects the Pi model, memory and storage. Checks them against the manifest's `supports`, picks the `small` or `standard` profile, and writes `/var/lib/inventory/node.json`. |
| `base` | Base packages and the `/etc/inventory`, `/var/lib/inventory` and `/opt/inventory` directories |
| `docker` | Docker Engine and Compose from Docker's apt repo (pinned by `docker_version` in `group_vars/all.yml`), daemon config, optional registry login |
| `stack` | Compose project in `/opt/inventory/stack`, the `inventory-stack` systemd unit (starts on boot), and waits for the node agent to be healthy |
| `inventoryctl` | Installs the `inventoryctl` CLI |
| `state` | Writes `/var/lib/inventory/installed.json`, last, so it only records versions that were applied successfully |

Planned for later milestones: `network`, `hardening`, `mysql`, `storage` (moving Docker and data to SSD), `devices` (udev rules for scanners and cameras).
