#!/usr/bin/env bash
# Runs inside the image while it's being built (see build.sh).
set -euo pipefail
export DEBIAN_FRONTEND=noninteractive

apt-get update -qq
apt-get install -y -qq --no-install-recommends \
  avahi-daemon dnsmasq-base iw network-manager python3 rfkill >/dev/null

# The image's own user, with no password. Imager normally creates this; our image
# skips Imager's settings. inventoryctl expects the first user at UID 1000.
if existing="$(getent passwd 1000 | cut -d: -f1)" && [ -n "$existing" ]; then
  [ "$existing" = inventory ] || usermod -l inventory -d /home/inventory -m "$existing"
  groupmod -n inventory "$(id -gn inventory)" 2>/dev/null || true
else
  useradd -m -u 1000 -s /bin/bash inventory
fi
usermod -aG sudo inventory
passwd -l inventory >/dev/null
passwd -l root >/dev/null
echo 'inventory ALL=(ALL) NOPASSWD:ALL' > /etc/sudoers.d/010_inventory
chmod 0440 /etc/sudoers.d/010_inventory

systemctl enable inventory-setup.service NetworkManager.service avahi-daemon.service
systemctl disable ssh.service 2>/dev/null || true
systemctl disable userconfig.service 2>/dev/null || true

# Imager settings are not used, and cloud-init could add its default user at first boot.
touch /etc/cloud/cloud-init.disabled
