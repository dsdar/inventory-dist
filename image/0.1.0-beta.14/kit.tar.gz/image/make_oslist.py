"""Add a built image to os-list.json, the list Raspberry Pi Imager reads.

  make_oslist.py --list os-list.json --info out/<image>.json --url <download folder>

One image serves several Pi models (the base, Raspberry Pi OS Lite 64-bit, is the same for
Pi 3, 4 and 5, and the install adapts to the hardware), so its entry is listed under each
model in OFFERED: Imager asks which Pi you have, then shows Home Inventory under it. A new
build replaces the entries it covers. No init_format, so Imager skips its settings screen.
"""

import argparse
import datetime
import json
import pathlib

ICONS = "https://downloads.raspberrypi.com/imager/icons"
MODELS = {
    "pi3": ("Raspberry Pi 3", "pi3-64bit", "RPi_3.png", "inclusive"),
    "pi4": ("Raspberry Pi 4", "pi4-64bit", "RPi_4.png", "inclusive"),
    "pi5": ("Raspberry Pi 5", "pi5-64bit", "RPi_5.png", "exclusive"),
}
# The models an image is offered for (owner, 2026-11-21: the owner has Pi 3s and a Pi 4; a model
# is added once an install is being tested on a real one). Pi 5: when there's one to test on.
OFFERED = ["pi3", "pi4"]


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--list", required=True, type=pathlib.Path)
    p.add_argument("--info", required=True, type=pathlib.Path)
    p.add_argument("--url", required=True, help="the release's download folder")
    args = p.parse_args()

    info = json.loads(args.info.read_text())
    offered = OFFERED if info["model"] in OFFERED else [info["model"]]
    tags = [MODELS[m][1] for m in offered]
    names = " / ".join(MODELS[m][0].replace("Raspberry Pi ", "Pi ") for m in offered)
    entry = {
        "name": f"Home Inventory ({names})",
        "description": f"Home Inventory setup image {info['version']}. Sets itself up from a phone: "
                       "dsdar.github.io/inventory-dist/setup.html",
        "icon": f"{ICONS}/{MODELS[offered[-1]][2]}",
        "url": f"{args.url}/{info['file']}",
        "extract_size": info["extract_size"],
        "extract_sha256": info["extract_sha256"],
        "image_download_size": info["image_download_size"],
        "image_download_sha256": info["image_download_sha256"],
        "release_date": datetime.date.today().isoformat(),
        "devices": tags,
    }

    current = json.loads(args.list.read_text()) if args.list.exists() else {"os_list": []}
    os_list = [e for e in current["os_list"] if not set(tags) & set(e.get("devices", []))] + [entry]
    listed = {t for e in os_list for t in e["devices"]}
    devices = [
        {"name": n, "tags": [t], "icon": f"{ICONS}/{i}", "description": n, "matching_type": m, "capabilities": []}
        for n, t, i, m in MODELS.values() if t in listed
    ]
    args.list.write_text(json.dumps({"imager": {"devices": devices}, "os_list": os_list}, indent=2) + "\n")
    print(f"{args.list}: {entry['name']} -> {info['version']}")


if __name__ == "__main__":
    main()
