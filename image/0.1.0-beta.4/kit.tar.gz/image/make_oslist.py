"""Add a built image to os-list.json, the list Raspberry Pi Imager reads.

  make_oslist.py --list os-list.json --info out/<image>.json --url <download folder>

One entry per Pi model: a new build replaces that model's entry. No init_format,
so Imager skips its settings screen: the image sets itself up.
"""

import argparse
import datetime
import json
import pathlib

ICONS = "https://downloads.raspberrypi.com/imager/icons"
MODELS = {
    "pi3": ("Raspberry Pi 3", "pi3-64bit", "RPi_3.png", "inclusive"),
    "pi4": ("Raspberry Pi 4", "pi4-64bit", "RPi_4.png", "inclusive"),
    "pi5": ("Raspberry Pi 5", "pi5-64bit", "RPi_5.png", "exclusive"),
}


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--list", required=True, type=pathlib.Path)
    p.add_argument("--info", required=True, type=pathlib.Path)
    p.add_argument("--url", required=True, help="the release's download folder")
    args = p.parse_args()

    info = json.loads(args.info.read_text())
    name, tag, icon, _ = MODELS[info["model"]]
    entry = {
        "name": f"Home Inventory ({name})",
        "description": f"Home Inventory setup image {info['version']}. Sets itself up from a phone.",
        "icon": f"{ICONS}/{icon}",
        "url": f"{args.url}/{info['file']}",
        "extract_size": info["extract_size"],
        "extract_sha256": info["extract_sha256"],
        "image_download_size": info["image_download_size"],
        "image_download_sha256": info["image_download_sha256"],
        "release_date": datetime.date.today().isoformat(),
        "devices": [tag],
    }

    current = json.loads(args.list.read_text()) if args.list.exists() else {"os_list": []}
    os_list = [e for e in current["os_list"] if tag not in e.get("devices", [])] + [entry]
    tags = {t for e in os_list for t in e["devices"]}
    devices = [
        {"name": n, "tags": [t], "icon": f"{ICONS}/{i}", "description": n, "matching_type": m, "capabilities": []}
        for n, t, i, m in MODELS.values() if t in tags
    ]
    args.list.write_text(json.dumps({"imager": {"devices": devices}, "os_list": os_list}, indent=2) + "\n")
    print(f"{args.list}: {entry['name']} -> {info['version']}")


if __name__ == "__main__":
    main()
