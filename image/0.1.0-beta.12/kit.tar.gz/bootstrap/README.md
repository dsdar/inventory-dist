# bootstrap

Two scripts take a freshly imaged Pi to a provisioned node. Both are published to the public distribution site, `https://dsdar.github.io/inventory-dist/`, and neither needs a token.

```bash
curl -fsSL https://dsdar.github.io/inventory-dist/install.sh | sudo bash                       # stable
curl -fsSL https://dsdar.github.io/inventory-dist/install.sh | sudo bash -s -- --channel beta  # pre-releases
```

## [`install.sh`](install.sh): the public entry point

Shared by all releases, so it is kept small and backward compatible. Only stable releases replace it on the dist site.

1. Reads `channel-<channel>.json` to find the latest infrastructure version (or uses `--version`).
2. Downloads that release's `manifest.json` and `bootstrap.sh`.
3. Verifies the manifest against the channel index, and the bootstrap against the manifest.
4. Runs the bootstrap. Options it doesn't know are passed through to it.

## [`bootstrap.sh`](bootstrap.sh): versioned with each release

1. Checks for a 64-bit OS and a supported Pi model.
2. Installs prerequisites (`ansible-core`, `python3-apt`, `curl`).
3. Downloads the release's `manifest.json` and `ansible-bundle.tar.gz`, verifies the bundle checksum, and checks the hardware and OS are listed in the manifest's `supports`.
4. Installs the release to `/opt/inventory/infra/<version>` (symlinked as `current`), and records the channel and dist URL in `/etc/inventory/updates.json` for later update checks.
5. Runs Ansible locally.

Options: `--version`, `--channel stable|beta`, `--dist-url`. `--registry-user` and `--registry-token` are needed only if container images are private.

Both scripts are safe to re-run, and both log to `/var/log/inventory-bootstrap.log`.

Step-by-step test procedure: [`docs/testing/m1-pi.md`](../../docs/testing/m1-pi.md).
