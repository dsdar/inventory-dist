#!/usr/bin/env bash
# Builds a Home Inventory card image: stock Raspberry Pi OS Lite plus the setup layer.
#
#   sudo build.sh --model pi3 --version 0.1.0-beta.1 --out out/
#
# Writes <out>/home-inventory-<model>-<version>.img.xz and a matching .json with the
# sizes and checksums Raspberry Pi Imager needs. Runs on x86 with QEMU binfmt registered.
# The image holds no secrets, no password and nothing unique to one Pi (ADR 0007).
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SETUP="$HERE/../setup"
# shellcheck source=/dev/null
. "$HERE/base.conf"

MODEL="" VERSION="" OUT=""
while [ $# -gt 0 ]; do
  case "$1" in
    --model) MODEL="${2:?}"; shift 2 ;;
    --version) VERSION="${2:?}"; shift 2 ;;
    --out) OUT="${2:?}"; shift 2 ;;
    *) echo "unknown option: $1" >&2; exit 2 ;;
  esac
done
if [ -z "$MODEL" ] || [ -z "$VERSION" ] || [ -z "$OUT" ]; then echo "needs --model, --version and --out" >&2; exit 2; fi
[ "$(id -u)" -eq 0 ] || { echo "run as root" >&2; exit 1; }

say() { printf '==> %s\n' "$*"; }
die() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }

work="$(mktemp -d)"
root="$work/root"
loop=""
cleanup() {
  if [ -n "$root" ] && mountpoint -q "$root"; then umount -R "$root" || umount -lR "$root" || true; fi
  [ -z "$loop" ] || losetup -d "$loop" || true
  rm -rf "$work"
}
trap cleanup EXIT

say "downloading the base image"
base="$work/base.img.xz"
curl -fsSL --retry 5 --retry-all-errors -o "$base" "$BASE_URL"
echo "$BASE_SHA256  $base" | sha256sum -c -
img="$work/image.img"
xz -dc -T0 "$base" > "$img"
rm -f "$base"

say "mounting"
loop="$(losetup -Pf --show "$img")"
mkdir -p "$root"
mount "${loop}p2" "$root"
mount "${loop}p1" "$root/boot/firmware"
mount --bind /dev "$root/dev"
mount --bind /dev/pts "$root/dev/pts"
mount -t proc proc "$root/proc"
mount -t sysfs sysfs "$root/sys"

say "what the base image does at first boot"
cat "$root/boot/firmware/cmdline.txt"
for f in user-data network-config meta-data; do
  if [ -f "$root/boot/firmware/$f" ]; then echo "--- $f"; cat "$root/boot/firmware/$f"; fi
done
tail -3 "$root/etc/passwd"
df -h "$root"

say "installing the setup layer"
install -D -m 0755 "$SETUP/inventory-setup" "$root/usr/local/sbin/inventory-setup"
install -D -m 0644 "$SETUP/inventory-setup.service" "$root/etc/systemd/system/inventory-setup.service"
install -D -m 0644 "$SETUP/hotspot-dnsmasq.conf" "$root/etc/inventory-setup/hotspot-dnsmasq.conf"
printf '{"version": "%s", "model": "%s", "base": "%s"}\n' "$VERSION" "$MODEL" "$(basename "$BASE_URL")" \
  > "$root/etc/inventory-image.json"

cp "$HERE/customize.sh" "$root/tmp/customize.sh"
mv "$root/etc/resolv.conf" "$root/etc/resolv.conf.image" 2>/dev/null || true
cp /etc/resolv.conf "$root/etc/resolv.conf"
printf '#!/bin/sh\nexit 101\n' > "$root/usr/sbin/policy-rc.d"
chmod +x "$root/usr/sbin/policy-rc.d"
chroot "$root" /bin/bash /tmp/customize.sh
rm -f "$root/usr/sbin/policy-rc.d" "$root/tmp/customize.sh" "$root/etc/resolv.conf"
mv "$root/etc/resolv.conf.image" "$root/etc/resolv.conf" 2>/dev/null || true

# The regulatory domain lets the Wi-Fi radio start without anyone choosing a country.
grep -q 'ieee80211_regdom' "$root/boot/firmware/cmdline.txt" \
  || sed -i '1 s/$/ cfg80211.ieee80211_regdom=US/' "$root/boot/firmware/cmdline.txt"

say "removing anything that must be unique to one Pi"
rm -f "$root"/etc/ssh/ssh_host_*
: > "$root/etc/machine-id"
rm -f "$root/var/lib/dbus/machine-id"
rm -rf "$root"/var/lib/apt/lists/* "$root"/var/cache/apt/archives/*.deb
find "$root/var/log" -type f -exec truncate -s 0 {} +

say "checking the result"
[ -L "$root/etc/systemd/system/multi-user.target.wants/inventory-setup.service" ] || die "setup service not enabled"
[ -z "$(find "$root/etc/ssh" -name 'ssh_host_*')" ] || die "SSH host keys left in the image"
[ ! -s "$root/etc/machine-id" ] || die "machine ID left in the image"
[ ! -e "$root/etc/systemd/system/multi-user.target.wants/ssh.service" ] || die "SSH is enabled"
for tool in nmcli wpa_supplicant dnsmasq iw ip rfkill avahi-daemon python3; do
  chroot "$root" sh -c "command -v $tool" >/dev/null || die "$tool is missing"
done
shadow="$(grep '^inventory:' "$root/etc/shadow" | cut -d: -f2)"
case "$shadow" in '!'*|'*'*) ;; *) die "the inventory user has a password" ;; esac
if cut -d: -f1,2 "$root/etc/shadow" | grep -E ':[^!*:]' ; then die "an account has a password"; fi
grep -q 'ieee80211_regdom=US' "$root/boot/firmware/cmdline.txt" || die "regulatory domain not set"
[ -e "$root/etc/cloud/cloud-init.disabled" ] || die "cloud-init is still on"
chroot "$root" systemctl list-unit-files --no-legend | grep -E "userconf|firstboot|first-boot|resize|rfkill|regenerate" || true
python3 -m py_compile "$root/usr/local/sbin/inventory-setup"
rm -rf "$root/usr/local/sbin/__pycache__"
df -h "$root"

fstrim "$root" 2>/dev/null || true
umount -R "$root"
losetup -d "$loop"
loop=""

say "compressing"
mkdir -p "$OUT"
name="home-inventory-$MODEL-$VERSION.img"
extract_size="$(stat -c %s "$img")"
extract_sha256="$(sha256sum "$img" | cut -d' ' -f1)"
xz -T0 -6 -c "$img" > "$OUT/$name.xz"
printf '{"model": "%s", "version": "%s", "file": "%s.xz", "extract_size": %s, "extract_sha256": "%s", "image_download_size": %s, "image_download_sha256": "%s"}\n' \
  "$MODEL" "$VERSION" "$name" "$extract_size" "$extract_sha256" \
  "$(stat -c %s "$OUT/$name.xz")" "$(sha256sum "$OUT/$name.xz" | cut -d' ' -f1)" > "$OUT/$name.json"
cat "$OUT/$name.json"
say "done"
